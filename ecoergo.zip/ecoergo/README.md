# EcoErgo: Move Better. Work Greener.

A free website for university staff: 3-minute desk exercise routines, a posture guide,
break reminders, a carbon (CO₂e) tracker, a Green Score and a progress dashboard.

> **Honesty note:** all carbon numbers are *illustrative estimates* and the "Load Demo Data"
> button creates *simulated* data. Never present either as real measurements or real
> institutional data. Healthcare visits are shown only as a "potential" and are never
> converted into carbon savings.

## How to run
1. Unzip the folder.
2. Double-click `index.html`. It opens in your browser. No install, no server.
3. Needs internet only for Chart.js (charts). Without internet, simple built-in charts are shown.

## What each file does
| File | Job |
|---|---|
| `index.html` | The page structure: sections, buttons, forms. |
| `style.css` | Colours, layout, dark mode, mobile layout, animations. |
| `data.js` | **Content you can edit**: exercises, routines, tips, emission factors, score targets, badges. |
| `script.js` | The brain: timers, reminders, calculator, score, charts, saving data. |
| `README.md` | This guide. |

## How the website works (simple)
- **Exercises:** pick a routine (4 exercises x 45 s = 3 min). The timer moves from one exercise
  to the next. When the routine ends, one "break" is logged automatically.
- **Posture:** tap numbered dots on the diagram to read tips. The self-check gives a % and is saved.
- **Reminders:** choose 30/45/60 min (or 1 min for a demo). A countdown runs; at zero you get a
  sound, a pop-up message and (if allowed) a browser notification. Works only while the page is open.
- **Carbon tracker:** enter pages avoided and trips avoided; it estimates CO₂e and saves it for today.
- **Dashboard:** cards, 3 charts, badges, Demo Data, CSV export, Reset.

## Everything is tappable (what you can click)
- **Exercise library:** tap a card to open its steps, caution and a "Start now" button. The star saves it to **My Routine**.
- **Badges:** tap a badge to see how close you are and a button that takes you to the right section.
- **Dashboard cards, hero numbers, charts:** tap them for a detail sheet; tap a chart bar to open that day.
- **Day log:** tap a row to edit that day with -/+ steppers, or clear it (two-tap confirm).
- **Method cards:** "Read more" opens the full explanation. **Insights** show simple patterns from your data.
- Sheets close with Esc, the X button, or by tapping outside; keyboard focus stays inside them.
- Timers use real clock time, so they stay accurate even if the tab is in the background.
- Tested automatically: 60 click/tap checks plus colour-contrast (light and dark), focus and timer tests.

## How the data flows
```
You click / type  ->  script.js updates the "state" object  ->  saved in localStorage (your browser)
                                                              ->  render() redraws numbers, charts, badges
```
State looks like: `days -> "2026-10-16" -> { breaks, pages, trips, km, co2, checks, ... }`.
Everything stays in your own browser. Other people cannot see it (a backend would be needed for that).

## How the carbon estimate is calculated
```
CO2e = pages x factor_per_page  +  trips x distance_km x factor_per_km(mode)
```
Factors are in `data.js` and are **illustrative**. For your report, replace them with cited values
(e.g. from a national emission-factor database) and write the source in your references.

## How the Green Score is calculated (0-100, last 7 days)
Each part = `min(value / target, 1) x max points`.

| Part | Target per week | Max points |
|---|---|---|
| Movement breaks | 20 | 40 |
| Paper avoided (pages) | 50 | 20 |
| Trips avoided | 5 | 20 |
| Posture-check days | 5 | 20 |

Example: 10 breaks -> 0.5 x 40 = 20 points. Add all four parts for the total.

## About the "recommendation" idea
This version recommends in a simple, explainable way: a **posture tip and eco tip of the day**
(rotating through `data.js`) and the **three routines** (Quick Reset, Neck & Shoulder, Desk Recharge).
There is no AI/tree engine because this project is about ergonomics, not tree planting.

## How to change the data
Open `data.js` in Notepad/VS Code and edit:
- `exercises`: titles, steps, caution text (BPT team should review).
- `routines`: which exercises appear in each 3-minute routine.
- `factors`: emission factors. `score`: targets and points. `dailyBreakGoal`: default 4.
- `postureTips`, `ecoTips`, `postureChecklist`, `badges`.
Save, then refresh the browser.

## How to deploy free (GitHub Pages)
1. Create a free account at github.com and click **New repository** (name e.g. `ecoergo`, Public).
2. Click **Add file -> Upload files**, drag in `index.html`, `style.css`, `script.js`, `data.js`, then Commit.
3. Go to **Settings -> Pages**. Under "Branch" choose `main` and `/ (root)`, then Save.
4. After a minute your site is live at `https://YOUR-USERNAME.github.io/ecoergo/`.

## What to say in your viva
- **Problem:** staff sit for long hours, causing neck/back pain. Clinic visits cost time, money and travel.
- **Solution:** a free website with short physiotherapy routines, reminders and an eco tracker.
- **Roles:** BPT team chose and verified exercises and safety text; B.Tech team built the site.
- **Tech:** HTML, CSS, JavaScript, Chart.js, localStorage, free GitHub Pages hosting (zero cost).
- **Green Score:** weekly, out of 100, from breaks, paper, trips and posture checks (show the table).
- **Carbon:** simple formula with illustrative factors; honest that they are estimates, to be replaced with cited factors.
- **Ethics/safety:** health disclaimer; discomfort sliders are self-ratings, not diagnosis; clinic visits are
  "potential only"; demo data is clearly labelled as simulated.
- **Limitations:** data stays in one browser; reminders need the page open; estimates not measurements.
- **Future work:** Telegram bot for reminders, backend for shared staff data, real GIFs/videos from the BPT team,
  survey and pre/post usability testing with university staff.

## Likely viva questions
- *Why localStorage?* Zero cost, no server, privacy-friendly; trade-off is no shared data.
- *Is the CO2 saving real?* No, it is an estimate from self-reported inputs and illustrative factors.
- *Does it replace a physiotherapist?* No. It gives general guidance; seek medical advice for persistent pain.
- *How did you test it?* Automated browser test of buttons, timers, calculator, reminders, demo data, CSV, mobile layout.
